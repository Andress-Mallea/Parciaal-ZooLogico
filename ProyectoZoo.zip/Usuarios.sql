--Creacion Vendedor
CREATE USER Vendedor WITH PASSWORD = 'Vendedor';
GO
USE [Proyecto_Zoologico];
CREATE USER Jhon FOR LOGIN Vendedor;
-- Otorgar permiso de INSERT en la tabla Facturas
GRANT INSERT ON Facturas TO Vendedor;
GO
-- Otorgar permiso de SELECT en la tabla Facturas (opcional)
GRANT SELECT ON Facturas TO Vendedor;
GO
-- Otorgar permiso de SELECT en la tabla Boletos (opcional, para verificar)
GRANT SELECT ON Boletos TO Vendedor;
GO
-- Otorgar permiso de SELECT en la tabla Empleados (si es necesario validar EmpleadoID_Venta)
GRANT SELECT ON Empleados TO Vendedor;
GO
-- Otorgar permisos en la tabla temporal VentasPendientes
GRANT SELECT, INSERT, DELETE ON VentasPendientes TO Vendedor;
GO
-- Denegar permisos de UPDATE y DELETE en Facturas
DENY UPDATE ON Facturas TO Vendedor;
DENY DELETE ON Facturas TO Vendedor;
GO
-- Denegar permisos de UPDATE y DELETE en Boletos
DENY UPDATE ON Boletos TO Vendedor;
DENY DELETE ON Boletos TO Vendedor;
GO
-- Denegar otros permisos relevantes en otras tablas seg�n sea necesario
DENY ALTER ON Facturas TO Vendedor;
DENY ALTER ON Boletos TO Vendedor;
DENY INSERT ON Empleados TO Vendedor;
DENY UPDATE ON Empleados TO Vendedor;
DENY DELETE ON Empleados TO Vendedor;

--Creacion Gerente
--CREATE LOGIN Gerente 
--WITH PASSWORD = 'Gerente';

USE [Proyecto_Zoologico];
CREATE USER Louis FOR LOGIN Gerente;
ALTER ROLE db_datareader ADD MEMBER Gerente

--Creacion DBA
--CREATE LOGIN DBA 
--WITH PASSWORD = 'DBA';

USE [Proyecto_Zoologico];
CREATE USER Marco FOR LOGIN DBA;
ALTER ROLE db_owner ADD MEMBER DBA