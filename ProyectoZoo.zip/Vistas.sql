
--4.6.
--Implementaci�n de vistas para reportes

CREATE VIEW Vista_Reporte_Ventas AS
SELECT c.[Nombre], c.[Apellido], b.[Precio], f.[ID.Factura], z.[Tipo de fauna]
FROM Cliente c
JOIN Factura f ON c.[ID.Cliente] = f.[ID.Cliente]
JOIN Boleto b ON f.[ID.Factura] = b.[ID.Factura]
JOIN Zonas z ON b.[ID.Zona] = z.[ID.Zona];

--SELECT * FROM Vista_Reporte_Ventas;
