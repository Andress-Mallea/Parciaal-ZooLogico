
-- Implementaci�n de vistas para reportes

CREATE VIEW Vista_Reporte_Ventas AS
SELECT
    p.Nombre,
    p.Apellido,
    b.Precio,
    f.FacturaID,
    z.Nombre_Zona
FROM Clientes cli
JOIN Personas p ON cli.PersonaID = p.PersonaID
JOIN Boletos b ON cli.ClienteID = b.ClienteID
JOIN Facturas f ON b.FacturaID = f.FacturaID
JOIN Zonas z ON b.ZonaID = z.ZonaID;

-- Para consultar la vista:
	SELECT * FROM Vista_Reporte_Ventas;