
----4.7.	
--Stored Procedure para Consultar Boletos de un Cliente 

CREATE PROCEDURE ObtenerBoletosClienteAvanzado
@Nombre NVARCHAR(10),
@Apellido NVARCHAR(10)
AS
BEGIN
    SELECT f.[ID.Factura], b.[Precio], b.[ID.Zona], z.[Tipo de fauna]
    FROM Factura f
    JOIN Cliente c ON f.[ID.Cliente] = c.[ID.Cliente]
    JOIN Boleto b ON f.[ID.Factura] = b.[ID.Factura]
    JOIN Zonas z ON b.[ID.Zona] = z.[ID.Zona]
    WHERE c.[Nombre] LIKE @Nombre + '%' OR c.[Apellido] LIKE @Apellido + '%';
END;

EXEC ObtenerBoletosClienteAvanzado @Nombre = 'CARLOS', @Apellido = 'Perez';
