
----4.7.	
-- Stored Procedure para Consultar Boletos de un Cliente

CREATE OR ALTER PROCEDURE ObtenerBoletosClienteAvanzado
@Nombre NVARCHAR(10),
@Apellido NVARCHAR(10)
AS
BEGIN
    SELECT F.FacturaID,f.CantidadDeBoletos, B.Precio, B.Tipo_boleto, B.ZonaID, Z.Nombre_Zona
    FROM Facturas as F
	JOIN Boletos AS B on F.FacturaID =B.FacturaID
    JOIN Clientes AS C ON B.ClienteID = C.ClienteID
	JOIN Personas as p on C.PersonaID = P.PersonaID
    JOIN Zonas as Z ON B.ZonaID = z.ZonaID
    WHERE P.Nombre LIKE @Nombre + '%' OR P.Apellido LIKE @Apellido + '%';
END;

-- Ejemplo de ejecuci�n del Stored Procedure
EXEC ObtenerBoletosClienteAvanzado @Nombre = 'Carlos', @Apellido = 'L�pez';