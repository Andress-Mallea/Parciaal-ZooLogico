-- CONSULTAS
--4.1.
-- Gerente Consulta 1: Obtener todos los animales de una zona espec�fica con conteo
SELECT
    z.ZonaID,
    z.Nombre_Zona,
    COUNT(a.AnimalID) AS Total_Animales
FROM Zonas z
LEFT JOIN Animales a ON z.ZonaID = a.ZonaID
WHERE z.ZonaID = 2 -- Reemplaza 1 con el ID de la zona que deseas consultar
GROUP BY z.ZonaID, z.Nombre_Zona;

--4.2.
-- Gerente Consulta 2: Consultar el historial de boletos de un cliente con total gastado (por nombre o apellido)
SELECT
    p.Nombre,
    p.Apellido,
    COUNT(b.ClienteID) AS Total_Boletos,
    SUM(b.Precio) AS Total_Gastado
FROM Clientes cli
JOIN Personas p ON cli.PersonaID = p.PersonaID
JOIN Boletos b ON cli.ClienteID = b.ClienteID
WHERE p.Nombre LIKE 'luis%' OR p.Apellido LIKE 'ramirez%'
GROUP BY p.Nombre, p.Apellido;
--4.3. 
-- Gerente Consulta 3: Obtener el n�mero total de visitas de clientes con desglose por zona
SELECT
    b.ZonaID,
    z.Nombre_Zona,
    COUNT(b.ClienteID) AS TotalVisitas
FROM Boletos b
JOIN Zonas z ON b.ZonaID = z.ZonaID
GROUP BY b.ZonaID, z.Nombre_Zona
ORDER BY TotalVisitas DESC;

--4.4.
-- Gerente Consulta 4: Ver las facturas generadas para un cliente en particular
-- con detalles de zona visitada (por nombre o apellido)
SELECT
    f.FacturaID,
    p.Nombre,
    p.Apellido,
    b.ZonaID,
    z.Nombre_Zona
FROM Facturas f
JOIN Boletos b ON f.FacturaID = b.FacturaID
JOIN Clientes cli ON b.ClienteID = cli.ClienteID
JOIN Personas p ON cli.PersonaID = p.PersonaID
JOIN Zonas z ON b.ZonaID = z.ZonaID
WHERE p.Nombre LIKE 'luis%' OR p.Apellido LIKE 'Perez%';