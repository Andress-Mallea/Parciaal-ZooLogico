-- CONSULTAS
--4.1.
--Consulta 1: Obtener todos los animales de una zona espec�fica con conteo 
--SELECT * FROM Zonas;
SELECT z.[ID.Zona], z.[Tipo de fauna], COUNT(a.[ID.Animales]) AS Total_Animales
FROM Zonas z
LEFT JOIN Animales a ON z.[ID.Animal] = a.[ID.Animales]
WHERE z.[ID.Zona] = 160
GROUP BY z.[ID.Zona], z.[Tipo de fauna];

--4.2.
--Consulta 2: Consultar el historial de boletos de un cliente con total gastado (por nombre o apellido)
--SELECT * FROM Cliente;
SELECT c.[ID.Cliente], c.[Nombre], c.[Apellido], COUNT(b.[ID.Factura]) AS Total_Boletos,
       SUM(CAST(b.[Precio] AS DECIMAL(10,2))) AS Total_Gastado
FROM Cliente c
JOIN Factura f ON c.[ID.Cliente] = f.[ID.Cliente]
JOIN Boleto b ON f.[ID.Factura] = b.[ID.Factura]
WHERE c.[Nombre] LIKE 'diego%' OR c.[Apellido] LIKE 'ramirez %'
GROUP BY c.[ID.Cliente], c.[Nombre], c.[Apellido];

--4.3. 
--Consulta 3: Obtener el n�mero total de visitas de clientes con desglose por zona

SELECT b.[ID.Zona], z.[Tipo de fauna], COUNT(b.[ID.Factura]) AS TotalVisitas
FROM Boleto b
JOIN Zonas z ON b.[ID.Zona] = z.[ID.Zona]
GROUP BY b.[ID.Zona], z.[Tipo de fauna]
ORDER BY TotalVisitas DESC;


--4.4.
--Consulta 4: Ver las facturas generadas para un cliente en particular 
--con detalles de zona visitada (por nombre o apellido)

SELECT f.[ID.Factura], c.[Nombre], c.[Apellido], b.[ID.Zona], z.[Tipo de fauna]
FROM Factura f
JOIN Cliente c ON f.[ID.Cliente] = c.[ID.Cliente]
JOIN Boleto b ON f.[ID.Factura] = b.[ID.Factura]
JOIN Zonas z ON b.[ID.Zona] = z.[ID.Zona]
WHERE c.[Nombre] LIKE 'luis%' OR c.[Apellido] LIKE 'Perez%';