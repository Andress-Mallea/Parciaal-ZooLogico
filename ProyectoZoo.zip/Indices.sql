-- Implementaci�n de �ndices eficientes

-- �ndice para mejorar la b�squeda de clientes en la tabla Facturas
CREATE INDEX idx_Facturas_ClienteID ON Facturas (Nit);

-- �ndice para optimizar la b�squeda de boletos por zona
CREATE INDEX idx_Boletos_ZonaID ON Boletos (ZonaID);

-- �ndice para mejorar consultas sobre empleados por zona
CREATE INDEX idx_Empleados_ZonaID ON Empleados (ZonaID);
/*
SET STATISTICS IO ON;
GO
SELECT * FROM Facturas WHERE ClienteID = 1;
GO
SET STATISTICS IO OFF;

SET STATISTICS IO ON;
GO
SELECT * FROM Boletos WHERE ZonaID = 1;
GO
SET STATISTICS IO OFF;

SET STATISTICS IO ON;
GO
SELECT * FROM Empleados WHERE ZonaID = 1;
GO
SET STATISTICS IO OFF;
*/
