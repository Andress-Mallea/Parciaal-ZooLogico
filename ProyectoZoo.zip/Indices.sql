--4.5.
--Implementaci�n de �ndices eficientes

-- �ndice para mejorar la b�squeda de clientes en la tabla Factura

--SET STATISTICS IO ON;
--GO
--SELECT * FROM Factura WHERE [ID.Cliente] =77;
--GO
--SET STATISTICS IO OFF; 


CREATE INDEX idx_factura_cliente ON Factura ([ID.Cliente]);

--DROP INDEX idx_factura_cliente ON Factura;


-- �ndice para optimizar la b�squeda de boletos por zona

--SET STATISTICS IO ON;
--GO
--SELECT * FROM Boleto WHERE [ID.Zona] = 1010;
--GO
--SET STATISTICS IO OFF;


CREATE INDEX idx_boleto_zona ON Boleto ([ID.Zona]);

--DROP INDEX idx_boleto_zona ON Boleto;


-- �ndice para mejorar consultas sobre empleados por zona
--SELECT * FROM ZONAS;
--SET STATISTICS IO ON;
--GO
--SELECT * FROM Empleado WHERE [ID.Zona] = 130;
--GO
--SET STATISTICS IO OFF;
--DROP INDEX idx_empleado_zona ON Empleado;

CREATE INDEX idx_empleado_zona ON Empleado ([ID.Zona]);

