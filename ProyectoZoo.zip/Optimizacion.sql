
--Optimizaci�n de la consulta de historial de boletos

--Consulta original:
--Select *  from cliente;
SELECT c.[ID.Cliente], c.[Nombre], c.[Apellido], f.[ID.Factura], b.[Precio], b.[ID.Zona]
FROM Cliente c
JOIN Factura f ON c.[ID.Cliente] = f.[ID.Cliente]
JOIN Boleto b ON f.[ID.Factura] = b.[ID.Factura]
WHERE c.[ID.Cliente] = 70;

--Consulta optimizada con �ndice y agregaci�n:

WITH HistorialBoletos AS (
    SELECT f.[ID.Factura], b.[Precio], b.[ID.Zona]
    FROM Factura f
    JOIN Boleto b ON f.[ID.Factura] = b.[ID.Factura]
    WHERE f.[ID.Cliente] = 70
)
SELECT *, COUNT(*) OVER() AS Total_Boletos
FROM HistorialBoletos;