-- Optimizaci�n de la consulta de historial de boletos

-- Consulta original adaptada:
SELECT
    p.Nombre,
    p.Apellido,
    f.FacturaID,
    b.Precio,
    z.Nombre_Zona
FROM Clientes cli
JOIN Personas p ON cli.PersonaID = p.PersonaID
JOIN Boletos b ON cli.ClienteID = b.ClienteID
JOIN Facturas f ON b.FacturaID = f.FacturaID
JOIN Zonas z ON b.ZonaID = z.ZonaID
WHERE cli.ClienteID = 7 -- Reemplaza 70 con un ClienteID existente en tu base de datos; ajust� a 7 por los datos insertados.
;

-- Consulta optimizada con CTE y agregaci�n adaptada:
WITH HistorialBoletos AS (
    SELECT
        b.Precio,
        z.Nombre_Zona,
        f.FacturaID
    FROM Boletos b
    JOIN Facturas f ON b.FacturaID = f.FacturaID
    JOIN Clientes cli ON b.ClienteID = cli.ClienteID
    JOIN Zonas z ON b.ZonaID = z.ZonaID
    WHERE cli.ClienteID = 7 -- Reemplaza 70 con un ClienteID existente en tu base de datos; ajust� a 7 por los datos insertados.
)
SELECT
    FacturaID,
    Precio,
    Nombre_Zona,
    COUNT(*) OVER() AS Total_Boletos_Cliente
FROM HistorialBoletos;
