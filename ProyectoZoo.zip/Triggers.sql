-- Trigger para evitar duplicidad de boletos en una misma factura
CREATE OR ALTER TRIGGER trg_PrevenirDuplicadosBoletos
ON Boletos
FOR INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM inserted i
        JOIN Boletos b ON i.FacturaID = b.FacturaID AND i.ZonaID = b.ZonaID
    )
    BEGIN
        RAISERROR ('No se pueden insertar boletos duplicados en la misma factura para la misma zona.', 16, 1);
        ROLLBACK TRANSACTION;
    END 
END;

-----------------------------------------------------------------------------------------
SELECT * FROM Facturas;
SELECT * FROM Zonas;
SELECT * FROM Boletos;

-- Prueba de inserci�n duplicada (deber�a fallar si ya existe un boleto con FacturaID=1 y ZonaID=1)
INSERT INTO Boletos (ClienteID, FacturaID, ZonaID, Precio, Tipo_boleto, Fecha_visita)
VALUES (1, 1, 1, 50.00, 'Adulto', '2025-04-10');

-- Prueba de inserci�n no duplicada (deber�a funcionar)
INSERT INTO Boletos (ClienteID, FacturaID, ZonaID, Precio, Tipo_boleto, Fecha_visita)
VALUES (2, 1, 2, 60.00, 'Adulto', '2025-04-10');

-----------------------------------------------------------------------------------------

-- Trigger para auditor�a de cambios en la tabla de empleados
CREATE TABLE Auditoria_Empleados (
    ID_Auditoria INT IDENTITY(1,1) PRIMARY KEY,
    EmpleadoID INT,
    Cambio VARCHAR(50),
    DetalleCambio VARCHAR(255),
    Fecha DATETIME DEFAULT GETDATE(),
    Usuario NVARCHAR(50) DEFAULT SUSER_NAME(),
    FOREIGN KEY (EmpleadoID) REFERENCES Empleados(EmpleadoID)
);
-- DROP TABLE Auditoria_Empleados;

CREATE OR ALTER TRIGGER trg_AuditoriaEmpleados
ON Empleados
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    DECLARE @Accion VARCHAR(10), @DetalleCambio VARCHAR(MAX), @EmpleadoID INT

    -- Identificar el tipo de acci�n (Inserci�n, Actualizaci�n, Eliminaci�n)
    IF EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted)
        SET @Accion = 'Actualizaci�n'
    ELSE IF EXISTS (SELECT 1 FROM inserted)
        SET @Accion = 'Inserci�n'
    ELSE
        SET @Accion = 'Eliminaci�n'

    -- Detalles del cambio para Actualizaci�n
    IF @Accion = 'Actualizaci�n'
    BEGIN
        SELECT
            @EmpleadoID = i.EmpleadoID,
            @DetalleCambio =
                'Salario: ' + COALESCE(CAST(d.Salario AS VARCHAR(20)), '') + ' -> ' + COALESCE(CAST(i.Salario AS VARCHAR(20)), '') +
                ', ZonaID: ' + COALESCE(CAST(d.ZonaID AS VARCHAR(10)), '') + ' -> ' + COALESCE(CAST(i.ZonaID AS VARCHAR(10)), '') +
                ', Rol: ' + COALESCE(d.Rol, '') + ' -> ' + COALESCE(i.Rol, '') +
                ', FechaDeContratacion: ' + COALESCE(CONVERT(VARCHAR(10), d.FechaDeContratacion, 120), '') + ' -> ' + COALESCE(CONVERT(VARCHAR(10), i.FechaDeContratacion, 120), '')
        FROM inserted i
        JOIN deleted d ON i.EmpleadoID = d.EmpleadoID;
    END
    ELSE IF @Accion = 'Inserci�n'
    BEGIN
        SELECT
            @EmpleadoID = i.EmpleadoID,
            @DetalleCambio = 'Inserci�n de nuevo empleado: PersonaID: ' + COALESCE(CAST(i.PersonaID AS VARCHAR(10)), '') +
                             ', FechaDeContratacion: ' + CONVERT(VARCHAR(10), i.FechaDeContratacion, 120) +
                             ', Salario: ' + CAST(i.Salario AS VARCHAR(20)) +
                             ', ZonaID: ' + COALESCE(CAST(i.ZonaID AS VARCHAR(10)), '') +
                             ', Rol: ' + i.Rol
        FROM inserted i;
    END
    ELSE IF @Accion = 'Eliminaci�n'
    BEGIN
        SELECT
            @EmpleadoID = d.EmpleadoID,
            @DetalleCambio = 'Eliminaci�n de empleado: PersonaID: ' + COALESCE(CAST(d.PersonaID AS VARCHAR(10)), '') +
                             ', FechaDeContratacion: ' + CONVERT(VARCHAR(10), d.FechaDeContratacion, 120) +
                             ', Salario: ' + CAST(d.Salario AS VARCHAR(20)) +
                             ', ZonaID: ' + COALESCE(CAST(d.ZonaID AS VARCHAR(10)), '') +
                             ', Rol: ' + d.Rol
        FROM deleted d;
    END

    -- Insertar en la tabla de auditor�a
    INSERT INTO Auditoria_Empleados (EmpleadoID, Cambio, DetalleCambio, Fecha, Usuario)
    VALUES (@EmpleadoID, @Accion, @DetalleCambio, GETDATE(), SUSER_NAME());
END;

-----------------------------------------------------------------------------------------
SELECT * FROM Auditoria_Empleados;
SELECT * FROM Empleados;
SELECT * FROM Personas; -- Para ver los nombres asociados a los Empleados

-- Ejemplo de inserci�n de un empleado (para activar el trigger de auditor�a)
INSERT INTO Empleados (PersonaID, FechaDeContratacion, Salario, ZonaID, Rol)
VALUES (1, '2025-04-05', 3000.00, 3, 'Cuidador');

-- Ejemplo de actualizaci�n de un empleado (para activar el trigger de auditor�a)
UPDATE Empleados
SET Salario = 3200.00, ZonaID = 4
WHERE EmpleadoID = 1;

-- Ejemplo de eliminaci�n de un empleado (para activar el trigger de auditor�a)
DELETE FROM Empleados WHERE EmpleadoID = 1;

--Triger para realizar ventas
-- Tabla temporal de ejemplo para contener los detalles de los boletos a registrar con la factura
CREATE TABLE VentasPendientes (
    FacturaTemporalID INT, -- Un ID temporal para identificar la factura a la que pertenecen estos boletos
    ClienteID INT NOT NULL,
    ZonaID INT NOT NULL,
    Precio DECIMAL(10,2) NOT NULL,
    Tipo_boleto VARCHAR(50) NOT NULL,
    Fecha_visita DATE NOT NULL
);

CREATE OR ALTER TRIGGER trg_RegistrarVentaDesdeFactura
ON Facturas
AFTER INSERT
AS
BEGIN
    -- Insertar los boletos asociados a la nueva factura desde la tabla temporal (ejemplo)
    INSERT INTO Boletos (ClienteID, ZonaID, FacturaID, Precio, Tipo_boleto, Fecha_visita)
    SELECT
        vp.ClienteID,
        vp.ZonaID,
        i.FacturaID, -- Obtenemos el FacturaID generado autom�ticamente
        vp.Precio,
        vp.Tipo_boleto,
        vp.Fecha_visita
    FROM inserted i -- Tabla que contiene las filas reci�n insertadas en Facturas
    INNER JOIN VentasPendientes vp ON i.FacturaID = vp.FacturaTemporalID; -- Suponiendo que relacionas la factura temporal con la real

    -- Limpiar la tabla temporal despu�s de procesar los boletos
    DELETE FROM VentasPendientes
    WHERE FacturaTemporalID IN (SELECT FacturaID FROM inserted);
END;

DECLARE @FacturaID_Temporal INT = 12345; -- Un ID temporal
DECLARE @ClienteID_Venta INT = 15; -- El ID del cliente que est� comprando

INSERT INTO VentasPendientes (FacturaTemporalID, ClienteID, ZonaID, Precio, Tipo_boleto, Fecha_visita)
VALUES
    (@FacturaID_Temporal, @ClienteID_Venta, 3, 50.00, 'Adulto', '2025-04-10'),
    (@FacturaID_Temporal, @ClienteID_Venta, 5, 35.00, 'Ni�o', '2025-04-10');
INSERT INTO Facturas (Nit, CantidadDeBoletos, Total)
VALUES ('87654321', 2, 85.00);
SELECT
    p.Nombre AS NombreCliente,
    p.Apellido AS ApellidoCliente,
    f.FacturaID,
    b.Precio,
    z.Nombre_Zona,
    b.Fecha_visita
FROM Boletos b
JOIN Facturas f ON b.FacturaID = f.FacturaID
JOIN Clientes c ON b.ClienteID = c.ClienteID
JOIN Personas p ON c.PersonaID = p.PersonaID
JOIN Zonas z ON b.ZonaID = z.ZonaID
WHERE p.Nombre = 'NombreDelCliente' AND p.Apellido = 'ApellidoDelCliente'
  AND f.FacturaID = 123; -- Reemplaza con el ID de la factura espec�fica