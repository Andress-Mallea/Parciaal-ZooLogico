CREATE TABLE Zonas (
    ZonaID INT IDENTITY(1,1) PRIMARY KEY,
    Nombre_Zona VARCHAR(100) NOT NULL,
);

CREATE TABLE Animales (
    AnimalID INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Especie VARCHAR(100) NOT NULL,
    Fecha_de_Llegada DATE NOT NULL,
	Fecha_de_Partida DATE NULL,
    Dieta VARCHAR(100) NOT NULL,
    ZonaID INT not null,
    EstadoSalud VARCHAR(100),
    FOREIGN KEY (ZonaID) REFERENCES Zonas(ZonaID)
);
CREATE TABLE Personas (
    PersonaID INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Apellido VARCHAR(100) NOT NULL,
    Direccion VARCHAR(255),
    Telefono VARCHAR(20),
    Email VARCHAR(100),
    ModifiedDate DATE NOT NULL DEFAULT GETDATE()
);
CREATE TABLE Clientes (
    ClienteID INT IDENTITY(1,1) PRIMARY KEY,
	PersonaID int not null,
    Fecha_registro DATE NOT NULL DEFAULT GETDATE(),
	ModifiedDate DATE NOT NULL DEFAULT GETDATE()
	Foreign key(PersonaID) references Personas(PersonaID)
);
CREATE TABLE Empleados (
    EmpleadoID INT IDENTITY(1,1) PRIMARY KEY,
	PersonaID int,
    FechaDeContratacion DATE NOT NULL,
    Salario DECIMAL(10,2) NOT NULL,
    ZonaID INT,
	ModifiedDate DATE NOT NULL DEFAULT GETDATE(),
	Foreign key(PersonaID) references Personas(PersonaID),
    FOREIGN KEY (ZonaID) REFERENCES Zonas(ZonaID)
);
CREATE TABLE Facturas (
    FacturaID INT IDENTITY(1,1) PRIMARY KEY,
	Nit varchar(100) not null default '12345678',
	CantidadDeBoletos int not null,
    Total DECIMAL(10,2) NOT NULL,
    FechaDeEmision DATETIME NOT NULL DEFAULT GETDATE(),
	ModifiedDate DATE NOT NULL DEFAULT GETDATE(),
);
CREATE TABLE Boletos (
    ClienteID INT NOT NULL,
	ZonaID int not null,
	FacturaID int not null,
    Precio DECIMAL(10,2) NOT NULL,
    Tipo_boleto VARCHAR(50) NOT NULL,
    Fecha_visita DATE NOT NULL,
	ModifiedDate DATE NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (ClienteID) REFERENCES Clientes(ClienteID),
	FOREIGN KEY (ZonaID) REFERENCES Zonas(ZonaID),
	FOREIGN KEY (FacturaID) REFERENCES Facturas(FacturaID)
);
alter table Empleados
	  add Rol varchar(100) not null
-- Insertando datos en la tabla Zonas
INSERT INTO Zonas (Nombre_Zona) VALUES
('Sabana Africana'),
('Selva Tropical'),
('Bosque Templado'),
('Zona �rtica'),
('Desierto'),
('Pradera Americana'),
('Humedal'),
('Monta�a Rocallosa'),
('Arrecife de Coral'),
('Aviario'),
('Reptilario'),
('Acuario de Agua Dulce');

-- Insertando datos en la tabla Animales
INSERT INTO Animales (Nombre, Especie, Fecha_de_Llegada, Fecha_de_Partida, Dieta, ZonaID, EstadoSalud) VALUES
('Le�n', 'Panthera leo', '2024-05-10', NULL, 'Carn�voro', 1, 'Saludable'),
('Jirafa', 'Giraffa camelopardalis', '2024-06-15', NULL, 'Herb�voro', 1, 'Saludable'),
('Cebra', 'Equus quagga', '2024-07-20', NULL, 'Herb�voro', 1, 'Saludable'),
('Tigre de Bengala', 'Panthera tigris tigris', '2023-11-01', NULL, 'Carn�voro', 2, 'Saludable'),
('Mono Ara�a', 'Ateles geoffroyi', '2024-01-25', NULL, 'Omn�voro', 2, 'Saludable'),
('Guacamayo Rojo', 'Ara macao', '2024-03-05', NULL, 'Frug�voro', 2, 'Saludable'),
('Oso Grizzly', 'Ursus arctos horribilis', '2023-09-18', NULL, 'Omn�voro', 3, 'Saludable'),
('Ciervo de Cola Blanca', 'Odocoileus virginianus', '2024-04-02', NULL, 'Herb�voro', 3, 'Saludable'),
('Lobo Gris', 'Canis lupus', '2023-12-12', NULL, 'Carn�voro', 3, 'Saludable'),
('Oso Polar', 'Ursus maritimus', '2023-07-01', NULL, 'Carn�voro', 4, 'Saludable'),
('Foca Com�n', 'Phoca vitulina', '2024-02-14', NULL, 'Carn�voro', 4, 'Saludable'),
('Ping�ino Emperador', 'Aptenodytes forsteri', '2024-03-22', NULL, 'Carn�voro', 4, 'Saludable'),
('Camello Dromedario', 'Camelus dromedarius', '2024-08-05', NULL, 'Herb�voro', 5, 'Saludable'),
('Suricata', 'Suricata suricatta', '2024-09-10', NULL, 'Insect�voro', 5, 'Saludable'),
('Coyote', 'Canis latrans', '2023-10-28', NULL, 'Omn�voro', 6, 'Saludable'),
('Bisonte Americano', 'Bison bison', '2024-05-20', NULL, 'Herb�voro', 6, 'Saludable'),
('Castor Americano', 'Castor canadensis', '2024-07-01', NULL, 'Herb�voro', 7, 'Saludable'),
('Nutria de R�o', 'Lontra canadensis', '2024-08-15', NULL, 'Carn�voro', 7, 'Saludable'),
('Cabra Montesa', 'Oreamnos americanus', '2023-11-22', NULL, 'Herb�voro', 8, 'Saludable'),
('Puma', 'Puma concolor', '2024-01-10', NULL, 'Carn�voro', 8, 'Saludable'),
('Pez Payaso', 'Amphiprioninae', '2024-06-01', NULL, 'Omn�voro', 9, 'Saludable'),
('Tortuga Marina', 'Chelonioidea', '2024-07-15', NULL, 'Omn�voro', 9, 'Saludable'),
('Caim�n', 'Alligatoridae', '2023-12-05', NULL, 'Carn�voro', 12, 'Saludable'),
('Iguana Verde', 'Iguana iguana', '2024-02-20', NULL, 'Herb�voro', 11, 'Saludable'),
('Pit�n Reticulada', 'Malayopython reticulatus', '2024-04-10', NULL, 'Carn�voro', 11, 'Saludable'),
('�guila Calva', 'Haliaeetus leucocephalus', '2024-05-25', NULL, 'Carn�voro', 10, 'Saludable'),
('Tuc�n Toco', 'Ramphastos toco', '2024-08-01', NULL, 'Frug�voro', 10, 'Saludable');

-- Insertando datos en la tabla Personas
INSERT INTO Personas (Nombre, Apellido, Direccion, Telefono, Email) VALUES
('Juan', 'P�rez', 'Calle Falsa 123', '77777777', 'juan.perez@email.com'),
('Mar�a', 'Gonz�lez', 'Avenida Siempreviva 742', '66666666', 'maria.gonzalez@email.com'),
('Carlos', 'L�pez', 'Pasaje El Candor 456', '88888888', 'carlos.lopez@email.com'),
('Ana', 'Rodr�guez', 'Barrio Lindo s/n', '70000000', 'ana.rodriguez@email.com'),
('Pedro', 'Mamani', 'Villa Esperanza #10', '60000000', 'pedro.mamani@email.com'),
('Sof�a', 'Vargas', 'Plan 3000, UV 5', '75555555', 'sofia.vargas@email.com'),
('Luis', 'Torres', 'Equipetrol Norte', '71111111', 'luis.torres@email.com'),
('Elena', 'Flores', 'La Ramada, Calle 2', '68888888', 'elena.flores@email.com'),
('Daniel', 'Ruiz', 'Urb. El Dorado', '73333333', 'daniel.ruiz@email.com'),
('Carmen', 'Castro', 'Mutualista, Av. Principal', '64444444', 'carmen.castro@email.com'),
('Jorge', 'Su�rez', 'Ciudad Sat�lite', '79999999', 'jorge.suarez@email.com'),
('Laura', 'Mendoza', 'Los Mangales', '69999999', 'laura.mendoza@email.com');

-- Insertando datos en la tabla Clientes
INSERT INTO Clientes (PersonaID) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12);

-- Insertando datos en la tabla Empleados
INSERT INTO Empleados (PersonaID, FechaDeContratacion, Salario, ZonaID, Rol) VALUES
(1, '2022-01-15', 3500.00, 1, 'Cuidador de Animales'),
(2, '2021-11-20', 4200.00, 2, 'Veterinario'),
(3, '2023-03-10', 3000.00, 3, 'Gu�a Tur�stico'),
(4, '2022-07-01', 2800.00, 4, 'Cajero'),
(5, '2023-05-05', 3800.00, NULL, 'Administrador'),
(6, '2024-01-20', 3200.00, 5, 'Cuidador de Animales'),
(7, '2022-09-25', 4500.00, 9, 'Bi�logo Marino'),
(8, '2023-08-12', 2900.00, 10, 'Cuidador de Aves'),
(9, '2024-02-28', 3100.00, 11, 'Cuidador de Reptiles'),
(10, '2023-06-18', 3300.00, 6, 'Educador Ambiental'),
(11, '2022-04-01', 4000.00, NULL, 'Gerente de Operaciones'),
(12, '2024-03-15', 2700.00, 7, 'Cuidador de Humedales');

-- Insertando datos en la tabla Facturas
INSERT INTO Facturas (Nit, CantidadDeBoletos, Total) VALUES
('98765432', 2, 100.00),
('11223344', 1, 60.00),
('55667788', 3, 150.00),
('22446688', 4, 200.00),
('77991133', 2, 120.00),
('33557799', 1, 75.00),
('44668800', 5, 250.00),
('88002244', 2, 90.00),
('66113355', 3, 180.00),
('99224466', 1, 50.00),
('12345678', 2, 110.00),
('56789012', 4, 220.00);

-- Insertando datos en la tabla Boletos
INSERT INTO Boletos (ClienteID, ZonaID, FacturaID, Precio, Tipo_boleto, Fecha_visita) VALUES
(1, 1, 1, 50.00, 'Adulto', '2025-04-10'),
(2, 2, 2, 60.00, 'Adulto', '2025-04-10'),
(3, 1, 3, 50.00, 'Adulto', '2025-04-11'),
(3, 3, 3, 50.00, 'Ni�o', '2025-04-11'),
(4, 4, 4, 50.00, 'Adulto', '2025-04-12'),
(4, 5, 4, 50.00, 'Adulto', '2025-04-12'),
(4, 6, 4, 50.00, 'Ni�o', '2025-04-12'),
(4, 7, 4, 50.00, 'Ni�o', '2025-04-12'),
(5, 8, 5, 60.00, 'Familiar', '2025-04-13'),
(5, 9, 5, 60.00, 'Familiar', '2025-04-13'),
(6, 10, 6, 75.00, 'VIP', '2025-04-14'),
(7, 1, 7, 50.00, 'Adulto', '2025-04-15'),
(7, 2, 7, 50.00, 'Adulto', '2025-04-15'),
(7, 3, 7, 50.00, 'Adulto', '2025-04-15'),
(7, 4, 7, 50.00, 'Adulto', '2025-04-15'),
(8, 5, 8, 45.00, 'Estudiante', '2025-04-16'),
(8, 6, 8, 45.00, 'Estudiante', '2025-04-16'),
(9, 7, 9, 60.00, 'Adulto', '2025-04-17'),
(9, 8, 9, 60.00, 'Adulto', '2025-04-17'),
(9, 9, 9, 60.00, 'Adulto', '2025-04-17'),
(10, 10, 10, 50.00, 'Adulto', '2025-04-18'),
(11, 11, 11, 55.00, 'Jubilado', '2025-04-19'),
(11, 12, 11, 55.00, 'Jubilado', '2025-04-19'),
(12, 1, 12, 55.00, 'Familiar', '2025-04-20'),
(12, 2, 12, 55.00, 'Familiar', '2025-04-20'),
(1, 3, 1, 50.00, 'Adulto', '2025-04-21');